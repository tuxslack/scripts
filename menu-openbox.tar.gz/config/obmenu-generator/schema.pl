#!/usr/bin/perl

# obmenu-generator - schema file

=for comment

    item:      add an item inside the menu               {item => ["command", "label", "icon"]},
    cat:       add a category inside the menu             {cat => ["name", "label", "icon"]},
    sep:       horizontal line separator                  {sep => undef}, {sep => "label"},
    pipe:      a pipe menu entry                         {pipe => ["command", "label", "icon"]},
    file:      include the content of an XML file        {file => "/path/to/file.xml"},
    raw:       any XML data supported by Openbox          {raw => q(...)},
    beg:       begin of a category                        {beg => ["name", "icon"]},
    end:       end of a category                          {end => undef},
    obgenmenu: generic menu settings                {obgenmenu => ["label", "icon"]},
    exit:      default "Sair" action                     {exit => ["label", "icon"]},

=cut

# NOTE:
#    * Keys and values are case sensitive. Keep all keys lowercase.
#    * ICON can be a either a direct path to an icon or a valid icon name
#    * Category names are case insensitive. (X-XFCE and x_xfce are equivalent)



# Localização do arquivo: ~/.config/obmenu-generator/schema.pl



require "$ENV{HOME}/.config/obmenu-generator/config.pl";

## Text editor
my $editor = $CONFIG->{editor};

our $SCHEMA = [

    #          COMMAND                 LABEL                         ICON
    {item => ['xdg-open .',       'Gerenciador de arquivos', 'system-file-manager']},
    {item => ['xfce4-terminal',   'Terminal',                'utilities-terminal']},
    {item => ['xdg-open http://', 'Navegador Web',           'web-browser']},
    {item => ['gmrun',            'Executar comando',        'system-run']},

    {sep => 'Categorias'},

    #          NAME            LABEL                      ICON
    {cat => ['utility',     'Acessórios',       'applications-utilities']},
    {cat => ['development', 'Desenvolvimento',  'applications-development']},
    {cat => ['education',   'Educação',         'applications-science']},
    {cat => ['game',        'Jogos',            'applications-games']},
    {cat => ['graphics',    'Gráficos',         'applications-graphics']},
    {cat => ['audiovideo',  'Multimídia',       'applications-multimedia']},
    {cat => ['network',     'Internet',         'applications-internet']},
    {cat => ['office',      'Escritório',       'applications-office']},
    {cat => ['other',       'Outros',           'applications-other']},
    {cat => ['settings',    'Configurações',    'applications-accessories']},
    {cat => ['system',      'Sistema',          'applications-system']},




    #             LABEL          ICON
    #{beg => ['My category',  'cat-icon']},
    #          ... some items ...
    #{end => undef},

    #            COMMAND     LABEL        ICON
    #{pipe => ['obbrowser', 'Disk', 'drive-harddisk']},

    ## Generic advanced settings
    #{sep       => undef},
    #{obgenmenu => ['Openbox Configurações', 'applications-engineering']},
    #{sep       => undef},

    ## Custom advanced settings
    {sep => undef},
    {beg => ['Configurações avançadas', 'applications-engineering']},

      # Configuration files
      {item => ["$editor ~/.conkyrc",              'Editar Conky',    'text-x-generic']},
      {item => ["$editor ~/.config/tint2/tint2rc", 'Editar painel Tint2', 'text-x-generic']},

      # obmenu-generator category
      {beg => ['Obmenu-Generator', 'accessories-text-editor']},
        {item => ["$editor ~/.config/obmenu-generator/schema.pl", 'Menu Schema', 'text-x-generic']},
        {item => ["$editor ~/.config/obmenu-generator/config.pl", 'Configuração de Menu', 'text-x-generic']},

        {sep  => undef},
        {item => ['obmenu-generator -s -c',    'Gerar um menu estático',             'accessories-text-editor']},
        {item => ['obmenu-generator -s -i -c', 'Gerar um menu estático com ícones',  'accessories-text-editor']},
        {sep  => undef},
        {item => ['obmenu-generator -p',       'Gerar um menu dinâmico',            'accessories-text-editor']},
        {item => ['obmenu-generator -p -i',    'Gerar um menu dinâmico com ícones', 'accessories-text-editor']},
        {sep  => undef},

        {item => ['obmenu-generator -d', 'Atualizar cache', 'view-refresh']},
      {end => undef},

      # Openbox category
      {beg => ['Openbox', 'openbox']},
        {item => ["$editor ~/.config/openbox/autostart", 'Inicialização automática do Openbox',   'text-x-generic']},
        {item => ["$editor ~/.config/openbox/rc.xml",    'Atalhos de teclado do Openbox',          'text-x-generic']},
        {item => ["$editor ~/.config/openbox/menu.xml",  'Menu do Openbox',        'text-x-generic']},
        {item => ['openbox --reconfigure',               'Reconfigurar Openbox', 'openbox']},
      {end => undef},
    {end => undef},

    {sep => undef},



    # Opção de saída do sistema


    {item => ['loginctl poweroff',  'Desligar',  '/usr/share/icons/hicolor/96x96/actions/xfsm-shutdown.png']},

    {item => ['loginctl reboot',    'Reiniciar', '/usr/share/icons/hicolor/96x96/actions/xfsm-reboot.png']},

    {item => ['loginctl suspend',   'Suspender', '/usr/share/icons/hicolor/96x96/actions/xfsm-suspend.png']},

    {item => ['loginctl hibernate', 'Hibernar',  '/usr/share/icons/hicolor/96x96/actions/xfsm-hibernate.png']},




    ## The xscreensaver lock command

    # {item => ['xscreensaver-command -lock', 'Bloquear tela', 'system-lock-screen']},

    {item => ['/usr/local/bin/lock.sh', 'Bloquear tela', 'system-lock-screen']},


    ## This option uses the default Openbox's "Sair" action
    {exit => ['Sair', 'application-exit']},

    ## This uses the 'oblogout' menu
    # {item => ['oblogout', 'Sair', 'application-exit']},
]
