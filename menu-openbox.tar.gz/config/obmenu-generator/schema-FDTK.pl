#!/usr/bin/perl

# obmenu-generator - schema file

=for comment

    item:      add an item inside the menu               {item => ["command", "label", "icon"]},
    cat:       add a category inside the menu             {cat => ["name", "label", "icon"]},
    sep:       horizontal line separator                  {sep => undef}, {sep => "label"},
    pipe:      a pipe menu entry                         {pipe => ["command", "label", "icon"]},
    file:      include the content of an XML file        {file => "/path/to/file.xml"},
    raw:       any XML data supported by Openbox          {raw => q(...)},
    beg:       begin of a category                        {beg => ["name", "icon"]},
    end:       end of a category                          {end => undef},
    obgenmenu: generic menu settings                {obgenmenu => ["label", "icon"]},
    exit:      default "Sair" action                     {exit => ["label", "icon"]},

=cut

# NOTE:
#    * Keys and values are case sensitive. Keep all keys lowercase.
#    * ICON can be a either a direct path to an icon or a valid icon name
#    * Category names are case insensitive. (X-XFCE and x_xfce are equivalent)



# Localização do arquivo: ~/.config/obmenu-generator/schema.pl



require "$ENV{HOME}/.config/obmenu-generator/config.pl";

## Text editor
my $editor = $CONFIG->{editor};

our $SCHEMA = [

    #          COMMAND                 LABEL                         ICON
    {item => ['xdg-open .',       'Gerenciador de arquivos', 'system-file-manager']},
    {item => ['xfce4-terminal',   'Terminal',                'utilities-terminal']},
    {item => ['xdg-open http://', 'Navegador Web',           'web-browser']},
    {item => ['gmrun',            'Executar comando',        'system-run']},

    {sep => 'Categorias'},

    #          NAME            LABEL                      ICON
    {cat => ['utility',     'Acessórios',       'applications-utilities']},
    {cat => ['development', 'Desenvolvimento',  'applications-development']},
    {cat => ['education',   'Educação',         'applications-science']},
    {cat => ['game',        'Jogos',            'applications-games']},
    {cat => ['graphics',    'Gráficos',         'applications-graphics']},
    {cat => ['audiovideo',  'Multimídia',       'applications-multimedia']},
    {cat => ['network',     'Internet',         'applications-internet']},
    {cat => ['office',      'Escritório',       'applications-office']},
    {cat => ['other',       'Outros',           'applications-other']},
    {cat => ['settings',    'Configurações',    'applications-accessories']},
    {cat => ['system',      'Sistema',          'applications-system']},





# ----------------------------------------------------------------------------------------


      # Categoria FDTK


      # /usr/share/applications/fdtk/
      # /usr/local/share/desktop-directories/


      {beg => ['Forense Digital', '/usr/share/icons/fdtk/forense.png']},



      # Subcategoria FDTK

      {beg => ['1 - Coleta dos Dados', '/usr/share/icons/fdtk/coleta.png']},


      {beg => ['Cadeia de Custódia', '/usr/share/icons/fdtk/help-contents.png']},

              {item => ['libreoffice --calc /usr/local/bin/fdtk/Formulario.xls',              'Formulário',              '/usr/share/icons/fdtk/application-vnd.ms-excel.png']},

      {end => undef},


      {beg => ['Capturar imagem', '/usr/share/icons/fdtk/applets-screenshooter.png']},

              {item => ['xfce4-screenshooter',              'Captura de tela',              'org.xfce.screenshooter']},

      {end => undef},


      {beg => ['Criar Imagem dos Dados', '/usr/share/icons/fdtk/drive-harddisk.png']},

              {item => ['/usr/local/bin/fdtk/aimage.sh',                            'aimage',           '/usr/share/icons/fdtk/drive-harddisk.png']},
              {item => ['pkexec env DISPLAY=:0 XAUTHORITY=/root/.Xauthority air',   'air',              '/usr/share/icons/fdtk/drive-harddisk.png']},
              {item => ['/usr/local/bin/fdtk/blktool.sh',                           'blktool',          '/usr/share/icons/fdtk/drive-harddisk.png']},
              {item => ['gksu dc3ddgui',                                            'dc3dd Gráfico',    '/usr/share/icons/fdtk/drive-harddisk.png']},
              {item => ['/usr/local/bin/fdtk/dcfldd.sh',                            'dcfldd',           '/usr/share/icons/fdtk/drive-harddisk.png']},
              {item => ['/usr/local/bin/fdtk/dd.sh',                                'dd',               '/usr/share/icons/fdtk/drive-harddisk.png']},
              {item => ['/usr/local/bin/fdtk/dd_rescue.sh',                         'dd_rescue',        '/usr/share/icons/fdtk/drive-harddisk.png']},
              {item => ['/usr/local/bin/fdtk/ddrescue.sh',                          'ddrescue',         '/usr/share/icons/fdtk/drive-harddisk.png']},
              {item => ['/usr/local/bin/fdtk/FSArchiver.sh',                        'FSArchiver',       '/usr/share/icons/fdtk/drive-harddisk.png']},
              {item => ['sudo mondoarchive',                                        'mondoarchive',     '/usr/share/icons/fdtk/drive-harddisk.png']},
              {item => ['sudo mondorestore',                                        'mondorestore',     '/usr/share/icons/fdtk/drive-harddisk.png']},
              {item => ['/usr/local/bin/fdtk/partclone.sh',                         'Partclone',        '/usr/share/icons/fdtk/partclone.png']},
              {item => ['/usr/local/bin/fdtk/Partimage.sh',                         'Partimage',        '/usr/share/icons/fdtk/drive-harddisk.png']},
              {item => ['/usr/local/bin/fdtk/rdd.sh',                               'rdd',              '/usr/share/icons/fdtk/drive-harddisk.png']},
              {item => ['/usr/local/bin/fdtk/rddi.sh',                              'rddi',             '/usr/share/icons/fdtk/drive-harddisk.png']},
              {item => ['/usr/local/bin/fdtk/sdd.sh',                               'sdd',              '/usr/share/icons/fdtk/drive-harddisk.png']},

      {end => undef},


      {beg => ['Dump de Memória', '/usr/share/icons/fdtk/user_auth.png']},

              {item => ['/usr/local/bin/fdtk/memdump.sh',              'memdump',              '/usr/share/icons/fdtk/user_auth.png']},

      {end => undef},


      {beg => ['Geração de HASH', '/usr/share/icons/fdtk/calc.png']},

              {item => ['/usr/local/bin/fdtk/md5sum.sh',              'md5sum',              '/usr/share/icons/fdtk/calc.png']},
              {item => ['/usr/local/bin/fdtk/sha1sum.sh',             'sha1sum',             '/usr/share/icons/fdtk/calc.png']},
              {item => ['/usr/local/bin/fdtk/sha256sum.sh',           'sha256sum',           'calc.png']},

      {end => undef},


      {beg => ['Identificação de HW', '/usr/share/icons/fdtk/hwinfo.png']},

              {item => ['/usr/local/bin/fdtk/discover.sh',            'Discover',               '/usr/share/icons/fdtk/hwinfo.png']},
              {item => ['sudo hardinfo',                              'Hardinfo',               '/usr/share/icons/fdtk/hwinfo.png']},
              {item => ['/usr/local/bin/fdtk/lshw-web.sh',            'lshw-Gráfico',           '/usr/share/icons/fdtk/hwinfo.png']},
              {item => ['sysinfo',                                    'Sysinfo',                '/usr/share/icons/fdtk/hwinfo.png']},
              {item => ['xsysinfo',                                   'Xsysinfo',               '/usr/share/icons/fdtk/hwinfo.png']},

      {end => undef},



      {beg => ['Limpar Mídias', '/usr/share/icons/fdtk/purge.png']},

              {item => ['su -c "/usr/local/bin/fdtk/limpar_midias.sh"',           'Limpar Midias',        '/usr/share/icons/fdtk/purge.png']},
              {item => ['/usr/local/bin/fdtk/wipe.sh',                            'wipe',                 '/usr/share/icons/fdtk/purge.png']},

      {end => undef},



      {beg => ['Rede', '/usr/share/icons/fdtk/coleta.png']},

              {item => ['/usr/local/bin/fdtk/aircrack-ng.sh',      'aircrack-ng',     '']},
              {item => ['/usr/local/bin/fdtk/arp.sh',              'arp',             '']},
              {item => ['/usr/local/bin/fdtk/arping.sh',           'Arping',          '']},
              {item => ['/usr/local/bin/fdtk/dig.sh',              'dig',             '']},
              {item => ['/usr/local/bin/fdtk/Hydra.sh',            'Hydra',           '/usr/share/icons/fdtk/Hydra.png']},
              {item => ['/usr/local/bin/fdtk/iwlist.sh',           'iwlist',          '']},
              {item => ['/usr/local/bin/fdtk/nmap.sh',             'nmap',            '/usr/share/icons/fdtk/nmap.png']},
              {item => ['/usr/local/bin/fdtk/tcpdump.sh',          'tcpdump',         '']},
              {item => ['/usr/local/bin/fdtk/whois.sh',            'whois',           '']},
              {item => ['/usr/local/bin/fdtk/wireshark.sh',        'wireshark',       '/usr/share/icons/fdtk/wireshark.png']},

      {end => undef},




      {end => undef},






      {beg => ['2 - Exame dos Dados', '/usr/share/icons/fdtk/exame.png']},


      {beg => ['Antivirus e Malware', '/usr/share/icons/fdtk/malware.png']},

              {item => ['su -c "/usr/local/bin/fdtk/clamscan.sh"',    'Clamscan',           '/usr/share/icons/fdtk/malware.png']},
              {item => ['clamtk',                                     'ClamTk',             '/usr/share/icons/fdtk/malware.png']},
              {item => ['/usr/local/bin/fdtk/nepenthes.sh',           'nepenthes',          '/usr/share/icons/fdtk/malware.png']},

      {end => undef},


      {beg => ['Arquivos Compactados', '/usr/share/icons/fdtk/compactado.png']},

              {item => ['/usr/local/bin/fdtk/7z.sh',           '7z',           '/usr/share/icons/fdtk/compactado.png']},
              {item => ['/usr/local/bin/fdtk/arj.sh',          'arj',          '/usr/share/icons/fdtk/compactado.png']},
              {item => ['/usr/local/bin/fdtk/bunzip2.sh',      'bunzip2',      '/usr/share/icons/fdtk/compactado.png']},
              {item => ['/usr/local/bin/fdtk/bzip2.sh',        'bzip2',        '/usr/share/icons/fdtk/compactado.png']},
              {item => ['/usr/local/bin/fdtk/cabextract.sh',   'cabextract',   '/usr/share/icons/fdtk/compactado.png']},
              {item => ['/usr/local/bin/fdtk/gzip.sh',         'gzip',         '/usr/share/icons/fdtk/compactado.png']},
              {item => ['/usr/local/bin/fdtk/gzrecover.sh',    'gzrecover',    '/usr/share/icons/fdtk/compactado.png']},
              {item => ['/usr/local/bin/fdtk/mscompress.sh',   'mscompress',   '/usr/share/icons/fdtk/compactado.png']},
              {item => ['/usr/local/bin/fdtk/orange.sh',       'orange',       '/usr/share/icons/fdtk/compactado.png']},
              {item => ['/usr/local/bin/fdtk/p7zip-full.sh',   'p7zip',        '/usr/share/icons/fdtk/compactado.png']},
              {item => ['/usr/local/bin/fdtk/rar.sh',          'rar',          '/usr/share/icons/fdtk/compactado.png']},
              {item => ['/usr/local/bin/fdtk/tar.sh',          'tar',          '/usr/share/icons/fdtk/tar.png']},
              {item => ['/usr/local/bin/fdtk/unace.sh',        'unace',        '/usr/share/icons/fdtk/compactado.png']},
              {item => ['/usr/local/bin/fdtk/unrar.sh',        'unrar',        '/usr/share/icons/fdtk/compactado.png']},
              {item => ['/usr/local/bin/fdtk/unshield.sh',     'unshield',     '/usr/share/icons/fdtk/compactado.png']},
              {item => ['/usr/local/bin/fdtk/unzip.sh',        'unzip',        '/usr/share/icons/fdtk/compactado.png']},
              {item => ['xarchiver',                           'Xarchiver',    '/usr/share/icons/fdtk/compactado.png']},
              {item => ['/usr/local/bin/fdtk/xz.sh',           'xz',           '/usr/share/icons/fdtk/compactado.png']},
              {item => ['/usr/local/bin/fdtk/zip.sh',          'zip',          '/usr/share/icons/fdtk/compactado.png']},
              {item => ['/usr/local/bin/fdtk/zoo.sh',          'zoo',          '/usr/share/icons/fdtk/compactado.png']},

      {end => undef},




      {beg => ['Arquivos de Imagem', '/usr/share/icons/fdtk/applications-graphics.png']},

              {item => ['/usr/local/bin/fdtk/dcraw.sh',           'dcraw',          '/usr/share/icons/fdtk/applications-graphics.png']},
              {item => ['/usr/local/bin/fdtk/fdtk-sh/exif.sh',    'exif',           '/usr/share/icons/fdtk/applications-graphics.png']},
              {item => ['/usr/local/bin/fdtk/exifautotran.sh',    'exifautotran',   '/usr/share/icons/fdtk/applications-graphics.png']},
              {item => ['/usr/local/bin/fdtk/exifprobe.sh',       'exifprobe',      '/usr/share/icons/fdtk/applications-graphics.png']},
              {item => ['/usr/local/bin/fdtk/exiftags.sh',        'exiftags',       '/usr/share/icons/fdtk/applications-graphics.png']},
              {item => ['/usr/local/bin/fdtk/exiftran.sh',        'exiftran',       '/usr/share/icons/fdtk/applications-graphics.png']},
              {item => ['/usr/local/bin/fdtk/exiv2.sh',           'exiv2',          '/usr/share/icons/fdtk/applications-graphics.png']},
              {item => ['/usr/local/bin/fdtk/jhead.sh',           'jhead',          '/usr/share/icons/fdtk/applications-graphics.png']},
              {item => ['/usr/local/bin/fdtk/jpeginfo.sh',        'jpeginfo',       '/usr/share/icons/fdtk/applications-graphics.png']},

      {end => undef},


      {beg => ['Arquivos MS', '/usr/share/icons/fdtk/winhelp.png']},

              {item => ['/usr/local/bin/fdtk/antiword.sh',           'antiword',             '/usr/share/icons/fdtk/winhelp.png']},
              {item => ['/usr/local/bin/fdtk/dumpster.sh',           'Dumpster',             '/usr/share/icons/fdtk/winhelp.png']},
              {item => ['/usr/local/bin/fdtk/fccu-docprop.sh',       'fccu-docprop',         '/usr/share/icons/fdtk/winhelp.png']},
              {item => ['/usr/local/bin/fdtk/mdb-hexdump.sh',        'mdb-hexdump',          '/usr/share/icons/fdtk/winhelp.png']},
              {item => ['/usr/local/bin/fdtk/readpst.sh',            'readpst',              '/usr/share/icons/fdtk/winhelp.png']},
              {item => ['/usr/local/bin/fdtk/reglookup.sh',          'reglookup',            '/usr/share/icons/fdtk/winhelp.png']},
              {item => ['/usr/local/bin/fdtk/reglookup-recover.sh',  'reglookup-recover',    '/usr/share/icons/fdtk/winhelp.png']},
              {item => ['/usr/local/bin/fdtk/reglookup-timeline.sh', 'reglookup-timeline',   '/usr/share/icons/fdtk/winhelp.png']},
              {item => ['/usr/local/bin/fdtk/regp.sh',               'regp',                 '/usr/share/icons/fdtk/winhelp.png']},
              {item => ['/usr/local/bin/fdtk/tnef.sh',               'tnef',                 '/usr/share/icons/fdtk/winhelp.png']},

      {end => undef},



      {beg => ['Auditoria', '/usr/share/icons/fdtk/distributor-logo.png']},

              {item => ['xterm -fa "Monospace" -fs 10 -geometry 113x59+500+100 -bg lightyellow -fg darkblue -T "Lynis - Sistema de auditoria e segurança para Linux..."  -e "echo -e "\033[1;31m\n\nInforme a senha do usuário Root.\n \033[0m" && su -c "/usr/local/bin/fdtk/lynis.sh""',              'Lynis',              '/usr/share/icons/fdtk/lynis.png']},

      {end => undef},



      {beg => ['Crypto-Stegano', '/usr/share/icons/fdtk/screenlets.png']},

              {item => ['/usr/local/bin/fdtk/bcrypt.sh',           'bcrypt',           '/usr/share/icons/fdtk/screenlets.png']},
              {item => ['/usr/local/bin/fdtk/ccrypt.sh',           'ccrypy',           '/usr/share/icons/fdtk/screenlets.png']},
              {item => ['gksu gdecrypt',                           'GDecrypt',         '/usr/share/icons/fdtk/screenlets.png']},
              {item => ['/usr/local/bin/fdtk/outguess.sh',         'Outguess',         '/usr/share/icons/fdtk/screenlets.png']},
              {item => ['/usr/local/bin/fdtk/stegcompare.sh',      'stegcompare',      '/usr/share/icons/fdtk/screenlets.png']},
              {item => ['/usr/local/bin/fdtk/stegdeimage.sh',      'Stegdeimage',      '/usr/share/icons/fdtk/screenlets.png']},
              {item => ['/usr/local/bin/fdtk/stegdetect.sh',       'Stegdetect',       '/usr/share/icons/fdtk/screenlets.png']},
              {item => ['gksu xsteg',                              'Xsteg',            '/usr/share/icons/fdtk/screenlets.png']},

      {end => undef},



      {beg => ['Editores HEX', '/usr/share/icons/fdtk/application-x-executable.png']},

              {item => ['bless',                                  'Bless',            '/usr/share/icons/fdtk/application-x-executable.png']},
              {item => ['ghex2',                                  'ghex2',            '/usr/share/icons/fdtk/application-x-executable.png']},
              {item => ['/usr/local/bin/fdtk/hexcat.sh',          'hexcat',           '/usr/share/icons/fdtk/application-x-executable.png']},
              {item => ['/usr/local/bin/fdtk/hexdump.sh',         'hexdump',          '/usr/share/icons/fdtk/application-x-executable.png']},

      {end => undef},



      {beg => ['Ferramentas do AFFLIB', '/usr/share/icons/fdtk/stock_task-recurring.png']},

              {item => ['/usr/local/bin/fdtk/afcat.sh',           'afcat',           '/usr/share/icons/fdtk/stock_task-recurring.png']},
              {item => ['/usr/local/bin/fdtk/afcompare.sh',       'afcompare',       '/usr/share/icons/fdtk/stock_task-recurring.png']},
              {item => ['/usr/local/bin/fdtk/afconvert.sh',       'afconvert',       '/usr/share/icons/fdtk/stock_task-recurring.png']},
              {item => ['/usr/local/bin/fdtk/afinfo.sh',          'afinfo',          '/usr/share/icons/fdtk/stock_task-recurring.png']},
              {item => ['/usr/local/bin/fdtk/afstats.sh',         'afstats',         '/usr/share/icons/fdtk/stock_task-recurring.png']},
              {item => ['/usr/local/bin/fdtk/afxml.sh',           'afxml',           '/usr/share/icons/fdtk/stock_task-recurring.png']},

      {end => undef},



      {beg => ['Localizar Dados', '/usr/share/icons/fdtk/localizar.png']},

              {item => ['/usr/local/bin/fdtk/blkcalc.sh',         'blkcalc',         '/usr/share/icons/fdtk/localizar2.png']},
              {item => ['/usr/local/bin/fdtk/blkcat.sh',          'blkcat',          '/usr/share/icons/fdtk/localizar2.png']},
              {item => ['/usr/local/bin/fdtk/blkid.sh',           'blkid',           '/usr/share/icons/fdtk/localizar2.png']},
              {item => ['/usr/local/bin/fdtk/blkls.sh',           'blkls',           '/usr/share/icons/fdtk/localizar2.png']},
              {item => ['/usr/local/bin/fdtk/blkstat.sh',         'blkstat',         '/usr/share/icons/fdtk/localizar2.png']},
              {item => ['/usr/local/bin/fdtk/catfish.sh',         'catfish',         '/usr/share/icons/hicolor/128x128/apps/org.xfce.catfish.png']},
              {item => ['/usr/local/bin/fdtk/glark.sh',           'glark',           '/usr/share/icons/fdtk/localizar2.png']},
              {item => ['',           '',           '']},
              {item => ['/usr/local/bin/fdtk/slocate.sh',         'slocate',         '/usr/share/icons/fdtk/localizar2.png']},

      {end => undef},



      {beg => ['Mactime dos Dados', '/usr/share/icons/fdtk/gftp.png']},

              {item => ['/usr/share/fdtk-sh/mac-robber.sh',        'mac-robber',        '/usr/share/icons/fdtk/gftp.png']},
              {item => ['/usr/share/fdtk-sh/mactime.sh',           'mactime',           '/usr/share/icons/fdtk/gftp.png']},

      {end => undef},



      {beg => ['Partições NTFS', '/usr/share/icons/fdtk/windisk.png']},

              {item => ['/usr/local/bin/fdtk/ntfs-3g.sh',          'ntfs-3g',            '/usr/share/icons/fdtk/windisk.png']},
              {item => ['/usr/local/bin/fdtk/ntfscat.sh',          'ntfscat',            '/usr/share/icons/fdtk/windisk.png']},
              {item => ['/usr/local/bin/fdtk/ntfsclone.sh',        'ntfsclone',          '/usr/share/icons/fdtk/windisk.png']},
              {item => ['/usr/local/bin/fdtk/ntfscluster.sh',      'ntfscluster',        '/usr/share/icons/fdtk/windisk.png']},
              {item => ['/usr/local/bin/fdtk/ntfsfix.sh',          'ntfsfix',            '/usr/share/icons/fdtk/windisk.png']},
              {item => ['/usr/local/bin/fdtk/ntfsinfo.sh',         'ntfsinfo',           '/usr/share/icons/fdtk/windisk.png']},
              {item => ['/usr/local/bin/fdtk/ntfslabel.sh',        'ntfslabel',          '/usr/share/icons/fdtk/windisk.png']},
              {item => ['/usr/local/bin/fdtk/ntfsls.sh',           'ntfsls',             '/usr/share/icons/fdtk/windisk.png']},

      {end => undef},



      {beg => ['Quebra de Senhas', '/usr/share/icons/fdtk/senha.png']},

              {item => ['/usr/local/bin/fdtk/chntpw.sh',           'chntpw',              '/usr/share/icons/fdtk/senha.png']},
              {item => ['/usr/local/bin/fdtk/fcrackzip.sh',        'fcrackzip',           '/usr/share/icons/fdtk/senha.png']},
              {item => ['/usr/local/bin/fdtk/john.sh',             'John the Ripper',     '/usr/share/icons/fdtk/john-logo.svg']},
              {item => ['/usr/local/bin/fdtk/medussa.sh',          'Medussa',             '/usr/share/icons/fdtk/medussa.png']},
              {item => ['/usr/local/bin/fdtk/ophcrack.sh',         'Ophcrack',            '/usr/share/icons/fdtk/ophcrack.xpm']},
              {item => ['/usr/local/bin/fdtk/pdfcrack.sh',         'PDFCrack',            '/usr/share/icons/fdtk/senha.png']},
              {item => ['/usr/local/bin/fdtk/rarcrack.sh',         'rarcrack',            '/usr/share/icons/fdtk/rarcrack.png']},

      {end => undef},



      {beg => ['Restaurar Dados', '/usr/share/icons/fdtk/restaurar.png']},

              {item => ['/usr/local/bin/fdtk/e2undel.sh',           'e2undel',            '/usr/share/icons/fdtk/harddrive.png']},
              {item => ['/usr/local/bin/fdtk/ext3grep.sh',          'ext3grep',           '/usr/share/icons/fdtk/imagem.png']},
              {item => ['/usr/local/bin/fdtk/extundelete.sh',       'Extundelete',        '/usr/share/icons/fdtk/imagem.png']},
              {item => ['/usr/local/bin/fdtk/fatback.sh',           'Fatback',            '/usr/share/icons/fdtk/windisk.png']},
              {item => ['/usr/local/bin/fdtk/foremost.sh',          'Foremost',           '/usr/share/icons/fdtk/imagem.png']},
              {item => ['/usr/local/bin/fdtk/magicrescue.sh',       'MagicRescue',        '/usr/share/icons/fdtk/applications-graphics.png']},
              {item => ['/usr/local/bin/fdtk/ntfsundelete.sh',      'ntfsundelete',       '/usr/share/icons/fdtk/windisk.png']},
              {item => ['/usr/local/bin/fdtk/photorec.sh',          'PhotoRec',           '/usr/share/icons/fdtk/PhotoRec.png']},
              {item => ['/usr/local/bin/fdtk/recover.sh',           'Recover',            '/usr/share/icons/fdtk/restaurar.png']},
              {item => ['/usr/local/bin/fdtk/recoverjpg.sh',        'recoverjpg',         '/usr/share/icons/fdtk/applications-graphics.png']},
              {item => ['/usr/local/bin/fdtk/scalpel.sh',           'Scalpel',            '/usr/share/icons/fdtk/imagem.png']},
              {item => ['/usr/local/bin/fdtk/scrounge-ntfs.sh',     'scrounge-ntfs',      '/usr/share/icons/fdtk/windisk.png']},
              {item => ['/usr/local/bin/fdtk/testdisk.sh',           'TestDisk',          '/usr/share/icons/fdtk/TestDisk.png']},

      {end => undef},



      {beg => ['RootKits', '/usr/share/icons/fdtk/b-bug.png']},

              {item => ['xterm -fa "Monospace" -fs 10 -geometry 180x59+180+0 -bg lightyellow -fg darkblue -T "Para identificar a presenca de RootKits no sistema - Chkrootkit..." -e "echo -e "\n\nInforme a senha do seu usuário abaixo.\n" ; sudo -s "/usr/local/bin/fdtk/chkrootkit.sh" "',           'Chkrootkit',           '/usr/share/icons/fdtk/b-bug.png']},


              {item => ['xterm -fa "Monospace" -fs 10 -geometry 180x59+180+0 -bg lightyellow -fg darkblue -T "Para identificar a presenca de RootKits no sistema - Rkhunter..."  -e "echo -e "\n\nInforme a senha do seu usuário abaixo.\n" ; sudo -s "/usr/local/bin/fdtk/rkhunter.sh""',           'Rkhunter',           '/usr/share/icons/fdtk/b-bug.png']},

      {end => undef},



      {beg => ['Visualizar Imagens', '/usr/share/icons/fdtk/imagem.png']},

              {item => ['comix',                                       'comix',                            '/usr/share/icons/fdtk/comix.png']},
              {item => ['f-spot',                                      'Gerenciador de Fotos F-Spot',      '/usr/share/icons/fdtk/f-spot.png']},
              {item => ['gthumb',                                      'gthumb',                           '/usr/share/icons/fdtk/imagem.png']},
              {item => ['/usr/local/bin/fdtk/imageindex.sh',           'imageindex',                       '/usr/share/icons/fdtk/imagem.png']},

      {end => undef},




        {item => ['',               '',         '']},
        {item => ['',               '',         '']},
        {item => ['',               '',         '']},


      {end => undef},




      {beg => ['3 - Análise das Evidências', '/usr/share/icons/fdtk/analise.png']},

              {item => ['/usr/local/bin/fdtk/cookie_cruncher.sh',      'cookie_cruncher',      '/usr/share/icons/fdtk/win.png']},
              {item => ['/usr/local/bin/fdtk/eindeutig.sh',            'eindeutig',            '/usr/share/icons/fdtk/win.png']},
              {item => ['/usr/local/bin/fdtk/fccu.evtreader.sh',       'fccu-evtreader',       '/usr/share/icons/fdtk/win.png']},
              {item => ['/usr/local/bin/fdtk/galleta.sh',              'galleta',              '/usr/share/icons/fdtk/win.png']},
              {item => ['/usr/local/bin/fdtk/grokevt.sh',              'GrokEVT',              '/usr/share/icons/fdtk/win.png']},
              {item => ['/usr/local/bin/fdtk/grokevt-addlog.sh',       'grokevt-addlog',       '/usr/share/icons/fdtk/win.png']},
              {item => ['/usr/local/bin/fdtk/grokevt-builddb.sh',      'grokevt-builddb',      '/usr/share/icons/fdtk/win.png']},
              {item => ['/usr/local/bin/fdtk/grokevt-dumpmsgs.sh',     'grokevt-dumpmsgs',     '/usr/share/icons/fdtk/win.png']},
              {item => ['/usr/local/bin/fdtk/grokevt-findlogs.sh',     'grokevt-findlogs',     '/usr/share/icons/fdtk/win.png']},
              {item => ['/usr/local/bin/fdtk/grokevt-parselog.sh',     'grokevt-parselog',     '/usr/share/icons/fdtk/win.png']},
              {item => ['/usr/local/bin/fdtk/grokevt-ripdll.sh',       'grokevt-ripdll',       '/usr/share/icons/fdtk/win.png']},
              {item => ['/usr/local/bin/fdtk/Mork.sh',                 'Mork',                 '/usr/share/icons/fdtk/win.png']},
              {item => ['/usr/local/bin/fdtk/pasco.sh',                'pasco',                '/usr/share/icons/fdtk/win.png']},
              {item => ['/usr/local/bin/fdtk/rifiuti.sh',              'rifiuti',              '/usr/share/icons/fdtk/win.png']},
              {item => ['/usr/local/bin/fdtk/vinetto.sh',              'vinetto',              '/usr/share/icons/fdtk/win.png']},
      {end => undef},





      {beg => ['Anti Análise Forense', '/usr/share/icons/fdtk/Anti-Forense.png']},


      {beg => ['Criptografia', '/usr/share/icons/fdtk/criptografia.png']},

              {item => ['/usr/local/bin/fdtk/AESCrypt.sh',                       'AESCrypt',       '/usr/share/icons/fdtk/criptografia1.png']},
              {item => ['/usr/local/bin/fdtk/cryptsetup.sh',                     'cryptsetup',     '/usr/share/icons/fdtk/criptografia1.png']},
              {item => ['/usr/local/bin/fdtk/gpg.sh',                            'gpg',            '/usr/share/icons/fdtk/criptografia1.png']},
              {item => ['/usr/local/bin/fdtk/veracrypt.sh',                      'VeraCrypt',      '/usr/share/icons/fdtk/criptografia1.png']},

      {end => undef},


              {item => ['/usr/local/bin/fdtk/mat2.sh',                   'mat2',                 '']},


      {end => undef},




      {beg => ['Scripts', '/usr/share/icons/fdtk/scripts.png']},

              {item => ['/usr/local/bin/fdtk/conf-FDTK.sh',                   'Configurar FDTK',                 '/usr/share/icons/fdtk/distributor-logo.png']},
              {item => ['/usr/local/bin/fdtk/Estacao_Forense.sh',             'Estacao_Forense',                 '/usr/share/icons/fdtk/distributor-logo.png']},
              {item => ['su -c "/usr/local/bin/fdtk/isolar-bad_blocks.sh"',   'Isolar bad blocks do seu HD',     '/usr/share/icons/fdtk/d-filelight.png']},
              {item => ['/usr/local/bin/fdtk/teclado.sh',                     'Teclado',                         '/usr/share/icons/fdtk/keyboardf.png']},

      {end => undef},



      {beg => ['ToolKits', '/usr/share/icons/fdtk/gnucash.png']},

              {item => ['/usr/local/bin/fdtk/autopsy.sh',              'Autopsy',              '/usr/share/icons/fdtk/Autopsy1.png']},
              {item => ['xdg-open "https://localhost/ptk/index.php"',  'ptk',                  '/usr/share/icons/fdtk/package_games_logic.png']},

      {end => undef},




        {item => ['/usr/local/bin/fdtk/CheckInstall.sh',               'CheckInstall',         '/usr/share/icons/fdtk/distributor-logo.png']},


      {end => undef},


# ----------------------------------------------------------------------------------------






    #             LABEL          ICON
    #{beg => ['My category',  'cat-icon']},
    #          ... some items ...
    #{end => undef},

    #            COMMAND     LABEL        ICON
    #{pipe => ['obbrowser', 'Disk', 'drive-harddisk']},

    ## Generic advanced settings
    #{sep       => undef},
    #{obgenmenu => ['Openbox Configurações', 'applications-engineering']},
    #{sep       => undef},

    ## Custom advanced settings
    {sep => undef},
    {beg => ['Configurações avançadas', 'applications-engineering']},

      # Configuration files
      {item => ["$editor ~/.conkyrc",              'Editar Conky',    'text-x-generic']},
      {item => ["$editor ~/.config/tint2/tint2rc", 'Editar painel Tint2', 'text-x-generic']},

      # obmenu-generator category
      {beg => ['Obmenu-Generator', 'accessories-text-editor']},
        {item => ["$editor ~/.config/obmenu-generator/schema.pl", 'Menu Schema', 'text-x-generic']},
        {item => ["$editor ~/.config/obmenu-generator/config.pl", 'Configuração de Menu', 'text-x-generic']},

        {sep  => undef},
        {item => ['obmenu-generator -s -c',    'Gerar um menu estático',             'accessories-text-editor']},
        {item => ['obmenu-generator -s -i -c', 'Gerar um menu estático com ícones',  'accessories-text-editor']},
        {sep  => undef},
        {item => ['obmenu-generator -p',       'Gerar um menu dinâmico',            'accessories-text-editor']},
        {item => ['obmenu-generator -p -i',    'Gerar um menu dinâmico com ícones', 'accessories-text-editor']},
        {sep  => undef},

        {item => ['obmenu-generator -d', 'Atualizar cache', 'view-refresh']},
      {end => undef},

      # Openbox category
      {beg => ['Openbox', 'openbox']},
        {item => ["$editor ~/.config/openbox/autostart", 'Inicialização automática do Openbox',   'text-x-generic']},
        {item => ["$editor ~/.config/openbox/rc.xml",    'Atalhos de teclado do Openbox',          'text-x-generic']},
        {item => ["$editor ~/.config/openbox/menu.xml",  'Menu do Openbox',        'text-x-generic']},
        {item => ['openbox --reconfigure',               'Reconfigurar Openbox', 'openbox']},
      {end => undef},
    {end => undef},

    {sep => undef},



    # Opção de saída do sistema


    {item => ['loginctl poweroff',  'Desligar',  '/usr/share/icons/hicolor/96x96/actions/xfsm-shutdown.png']},

    {item => ['loginctl reboot',    'Reiniciar', '/usr/share/icons/hicolor/96x96/actions/xfsm-reboot.png']},

    {item => ['loginctl suspend',   'Suspender', '/usr/share/icons/hicolor/96x96/actions/xfsm-suspend.png']},

    {item => ['loginctl hibernate', 'Hibernar',  '/usr/share/icons/hicolor/96x96/actions/xfsm-hibernate.png']},




    ## The xscreensaver lock command

    # {item => ['xscreensaver-command -lock', 'Bloquear tela', 'system-lock-screen']},

    {item => ['/usr/local/bin/lock.sh', 'Bloquear tela', 'system-lock-screen']},


    ## This option uses the default Openbox's "Sair" action
    {exit => ['Sair', 'application-exit']},

    ## This uses the 'oblogout' menu
    # {item => ['oblogout', 'Sair', 'application-exit']},
]
